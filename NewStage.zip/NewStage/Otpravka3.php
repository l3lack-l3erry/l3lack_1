<!DOCTYPE html>
<html>

<head>
	<meta charset="UTF-8">
	<title>NewStage | Отправка формы</title>
</head>
<link rel="icon" href="Logo.ico" type="image/x-icon">
<link rel="stylesheet" a href="CSS.css" type="text/css">
<link rel="stylesheet" a href="CSS2.css" type="text/css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
<script src="Script.js"></script>

<body class="bckgr-1">
	<div class="blockBanner2">
		<table width="100%">
			<tr>
				<td>
					<font color="white">
						<h1 align="center"><img src="Tel.png" width="45" height="45"><b>Контакты</b><img src="Tel.png" width="45" height="45">
							<center><u><i>+375(44)511-59-59</i></u><br>
								<u><i>+7(928)634-91-98</i></u>
						</h1>
						</center>
					</font>
				</td>
				<td align="center"><a href="https://www.instagram.com/newstage_parts/" target="_blank"><img class="shrink" src="NewStage2.png" width="600" height="350"></a></td>
				<td>
					<font color="white">
						<h1 align="center"><img src="Loc.png" width="40" height="40"><b>Наш офис</b><img src="Loc.png" width="40" height="40"></h1>
						<center>
							<form action="https://goo.gl/maps/Gt4agNkxCpWHwFgr5" target="_blank">
								<button class="shine-button">Google-карта</button>
							</form>
							<form action="https://yandex.by/maps/-/CDQMV48W" target="_blank">
								<button class="shine-button">Yandex-карта</button>
							</form>
						</center>
					</font>
				</td>
			</tr>
		</table>
	</div>
	<div class="blockBanner">
		<table width="100%">
			<tr>
				<td style="text-align: center;" rowspan="2">
					<font size="4">
						<h1><img src="Otzv.png" width="45" height="45"><u>Отзывы</u><img src="Otzv.png" width="45" height="45"></h1>
					</font>
				</td>
				<td style="text-align: center;">
					<form action="NewStage.html">
						<button class="gradient-button">Главная</button>
					</form>
				</td>
				<td style="text-align: center;" rowspan="2">
					<font size="4">
						<h1><img src="Otzv.png" width="45" height="45"><u>Отзывы</u><img src="Otzv.png" width="45" height="45"></h1>
					</font>
				</td>
			</tr>
			<tr>
				<td style="text-align: center;">
					<font color="white">
						<div class="dropdown">
							<button class="dropbtn">Меню сайта</button>
							<div class="dropdown-content">
								<a href="Zapchasti v nalichii.html"><img src="Zap.png" width="20" height="20">Запчасти в
									наличии<img src="Zap.png" width="20" height="20"></a>
								<a href="Zakazat zapchast.html"><img src="Zak.png" width="20" height="20">Заказать
									запчасть<img src="Zak.png" width="20" height="20"></a>
								<a href="Steklo pod zakaz.html"><img src="Stek.png" width="20" height="20">Стекло под
									заказ<img src="Stek.png" width="20" height="20"></a>
								<a href="Feedback.html"><img src="Feed.png" width="20" height="20">Обратная связь<img src="Feed.png" width="20" height="20"></a>
								<a href="Reshim raboty.html"><img src="Vrem.png" width="20" height="20">Режим работы<img src="Vrem.png" width="20" height="20"></a>
								<a href="Otzivi.html"><img src="Otzv.png" width="20" height="20">Отзывы<img src="Otzv.png" width="20" height="20"></a>
								<a href="Novosti.html"><img src="News.png" width="20" height="20">Новости<img src="News.png" width="20" height="20"></a>
								<a href="O companii.html"><img src="NewStageS.png" width="60" height="25">О компании<img src="NewStageS.png" width="60" height="25"></a>
							</div>
						</div>
					</font>
				</td>
			</tr>
		</table>
	</div>
	<font color="white" size="4">
		<h1 align="center">Запрос отправлен, после проверки Ваш отзыв будет опубликован.<br>
			С уважением, команда NewStage.
		</h1>
	</font>
	<div class="blockBanner">
		<footer>
			<table width="100%">
				<tr>
					<td style="text-align: center;">
						<h1 align="center"><img src="Texp.png" width="48">Техническая поддержка<img src="Texp.png" width="48"><br>
							<u><i>+375(33)301-78-62</i></u>
						</h1>
					</td>
					<td>
						<font color="black">
							<h1 align="center">Следи за нами<br>
								<a href="https://www.instagram.com/newstage_parts/" target="_blank">
									<img class="shrink" src="Inst.png" width="45" height="45"></a>&nbsp;&nbsp;&nbsp;
								<a href="https://t.me/newsta4e" target="_blank"><img class="shrink" src="Teleg.png" width="45" height="45"></a>&nbsp;&nbsp;&nbsp;
								<a href="viber://chat?number=%2B375445115959" target="_blank"><img class="shrink" src="Vibe.png" width="45" height="45"></a>&nbsp;&nbsp;&nbsp;
								<a href="https://api.whatsapp.com/send?phone=375445115959" target="_blank"><img class="shrink" src="Whats.png" width="45" height="45"></a>
							</h1>
						</font>
					</td>
					<td style="text-align: center;">
						<h1 align="center"><img src="Texp.png" width="48">Техническая поддержка<img src="Texp.png" width="48"><br>
							<u><i>+375(29)325-10-29</i></u>
						</h1>
					</td>
				</tr>
			</table>
		</footer>
		<hr>
		<h2 align="center" class="ns">© NewStage | 2023</h2>
	</div>

	<div class="btn-up btn-up_hide" title="Наверх"></div>

	<script>
		const btnUp = {
			el: document.querySelector('.btn-up'),
			show() {
				this.el.classList.remove('btn-up_hide');
			},
			hide() {
				this.el.classList.add('btn-up_hide');
			},
			addEventListener() {
				window.addEventListener('scroll', () => {
					const scrollY = window.scrollY || document.documentElement.scrollTop;
					scrollY > 400 ? this.show() : this.hide();
				});

				document.querySelector('.btn-up').onclick = () => {
					window.scrollTo({
						top: 0,
						left: 0,
						behavior: 'smooth'
					});
				}
			}
		}
		btnUp.addEventListener();
	</script>

	<script>
		$(document).ready(function myFunction() {
			$(".dropdown").click(function() {
				$(this).find(".dropdown-content").slideToggle("slow");
			});
		});
		$(document).on("click", function(event) {
			var $trigger = $(".dropdown");
			if ($trigger !== event.target && !$trigger.has(event.target).length) {
				$(".dropdown-content").slideUp("slow");
			}
		});
	</script>
</body>

</html>
<?php
$name = $_POST['name'];
$rate = $_POST['rate'];
$mess = $_POST['mess'];

$to = "form@newstage.by";
$date = date("d.m.Y");
$time = date("h:i");
$from = $email;
$subject = "Заявка c сайта (отзыв)";


$msg = "
    Имя: $name 
    Оценка: $rate 
    Сообщение: $mess";
mail($to, $subject, $msg, "From: $to ");

?>