<?php

$login = filter_var(trim($_POST['login']));
$pass = filter_var(trim($_POST['pass']));

if (mb_strlen($login) < 5 || mb_strlen($login) > 90) {
    echo "Недопустимая длина логина.";
    exit();
}

$pass = md5($pass . "forhktkntuhpi"); // Создаем хэш из пароля

$mysql = new mysqli('localhost', 'root', '', 'register-bd');

$result = $mysql->query("SELECT * FROM `users` WHERE `login` = '$login' AND `pass` = '$pass'");
$user = $result->fetch_assoc(); // Конвертируем в массив
if (is_countable($user) && count($user) == 0) {
    echo "Такой пользователь не найден.";
    exit();
} else if (is_countable($user) && count($user) == 0) {
    echo "Логин или пароль введены неверно";
    exit();
}

setcookie('user', $user['name'], time() + 3600, "/");

$mysql->close();

header('Location: NewStageReg.html');
