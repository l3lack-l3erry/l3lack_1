<?php
    $host = 'localhost';  // Хост, у нас все локально
    $user = 'root';    // Имя созданного вами пользователя
    $pass = ''; // Установленный вами пароль пользователю
    $db_name = 'Аптека';   // Имя базы данных
    $link = mysqli_connect($host, $user, $pass, $db_name); // Соединяемся с базой

    // Ругаемся, если соединение установить не удалось
    if (!$link) {
      echo 'Не могу соединиться с БД. Код ошибки: ' . mysqli_connect_errno() . ', ошибка: ' . mysqli_connect_error();
      exit;
    }
    //Если переменная Name передана
  if (isset($_POST["name"])) {
    //Вставляем данные, подставляя их в запрос
    $sql = mysqli_query($link, "INSERT INTO `заказы` (`Имя`, `Номер телефона`,`Артикул`,`Количество упаковок`,`Несколько препаратов`,`Тип доставки`,`Варианты оплаты`) VALUES ('{$_POST['name']}', '{$_POST['phone']}','{$_POST['artikul']}','{$_POST['kolich']}','{$_POST['mess']}','{$_POST['dostavka']}','{$_POST['oplata']}')");
    //Если вставка прошла успешно
    if ($sql) {
      echo ' <!DOCTYPE html>

<html>

<head>

<style>

body {

  
  .te {
    
    font-family: Strong-Regular; /* Гарнитура шрифта */
    src: url(Strong-Regular.ttf); /* Путь к файлу со шрифтом */
text-align: center;
color: white;
line-height: 50px;
font-size: 36px;
    
}
.btn-popular {
    cursor: pointer;
    border-radius: 10px;
    border: none;
    width: 240px;
    height: 38px;
    text-align: center;
    font-size: 17px;
    background-color: rgb(34, 113, 179);
    color: white;
}

.btn-popular:hover {
    background-color: rgb(0, 83, 138);
}

.btn-popular:active {
    background-color: rgb(34, 113, 179);
}
    .shapka {
    
    background-color: rgb(127, 199, 255);
    padding: 50px;
    height: 730px;
    
}

</style>
</head>
 <div class="shapka">
<BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR>
      <h1 align = center class = "te">Спасибо за заказ, в ближайшее время <br>с Вами свяжутся для уточнения деталей!<BR><BR>  <center><a href="Korzina.html"><button class="btn-popular"><b>Корзина</b></button></a></center></div></html>';
    } else {
    
    }
  }
  ?>